class User {
  final String uid;
  final String username;
  final String email;
  final String photoUrl;

  User({
    required this.uid,
    required this.username,
    required this.email,
    required this.photoUrl,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      uid: map['uid'] ?? '',
      username: map['username'] ?? '',
      email: map['email'] ?? '',
      photoUrl: map['photoUrl'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'username': username,
      'email': email,
      'photoUrl': photoUrl,
    };
  }
}