import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:instagram_flutter/providers/user_provider.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  @override
  void initState() {
    super.initState();
    // Load user data safely
    Provider.of<UserProvider>(context, listen: false).refreshUser();
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Socially'),
        centerTitle: true,
      ),
      body: userProvider.getUser == null
          ? const Center(child: CircularProgressIndicator())
          : Center(
              child: Text(
                'Welcome, ${userProvider.getUser!.username}',
                style: const TextStyle(fontSize: 18),
              ),
            ),
    );
  }
}