import 'package:flutter/material.dart';
import 'package:instagram_flutter/models/user.dart';

class UserProvider with ChangeNotifier {
  User? _user;

  User? get getUser => _user;

  // Dummy fetch (safe for templates)
  Future<void> refreshUser() async {
    // In real apps this pulls from Firebase
    _user = User(
      uid: 'demo_uid',
      username: 'demo_user',
      email: 'demo@email.com',
      photoUrl: '',
    );
    notifyListeners();
  }
}