const webScreenSize = 600;
